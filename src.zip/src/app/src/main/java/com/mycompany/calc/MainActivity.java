package com.mycompany.calc;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.Bundle;
import android.util.Base64;
import android.speech.RecognizerIntent;
import android.view.Window;
import android.webkit.JavascriptInterface;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;

public class MainActivity extends Activity {
    private WebView web;
    private ValueCallback<Uri[]> filePathCallback;
    private String nativeKind = "";
    private static final int REQ_FILE = 1;
    private static final int REQ_NATIVE = 2;
    private static final int REQ_VOICE = 3;

    // Мост: страница вызывает AndroidPicker.pick(...) и получает файл обратно
    public class Bridge {
        @JavascriptInterface
        public void voice() {
            runOnUiThread(new Runnable() {
                public void run() {
                    Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ru-RU");
                    i.putExtra(RecognizerIntent.EXTRA_PROMPT, "Скажите пример");
                    try {
                        startActivityForResult(i, REQ_VOICE);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Голосовой ввод недоступен на этом устройстве", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }

        @JavascriptInterface
        public void pick(String kind, String mime) {
            nativeKind = kind;
            final Intent i = new Intent(Intent.ACTION_GET_CONTENT);
            i.addCategory(Intent.CATEGORY_OPENABLE);
            i.setType(mime == null || mime.length() == 0 ? "*/*" : mime);
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        startActivityForResult(Intent.createChooser(i, "Выберите файл"), REQ_NATIVE);
                    } catch (Exception e) {
                        Toast.makeText(MainActivity.this, "Не удалось открыть выбор файла", Toast.LENGTH_LONG).show();
                    }
                }
            });
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        try { requestWindowFeature(Window.FEATURE_NO_TITLE); } catch (Exception e) { }
        web = new WebView(this);
        web.setBackgroundColor(Color.BLACK);
        setContentView(web);
        try { if (getActionBar() != null) getActionBar().hide(); } catch (Exception e) { }
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            getWindow().setStatusBarColor(Color.BLACK);
            getWindow().setNavigationBarColor(Color.BLACK);
        }

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setMediaPlaybackRequiresUserGesture(false);

        web.addJavascriptInterface(new Bridge(), "AndroidPicker");

        // Запрос микрофона при первом запуске (дальше система запоминает выбор)
        if (android.os.Build.VERSION.SDK_INT >= 23
                && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 10);
        }
        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            // страница может просить микрофон (getUserMedia)
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(new Runnable() {
                    public void run() { request.grant(request.getResources()); }
                });
            }

            // запасной вариант для обычного <input type=file>
            @Override
            public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
                intent.addCategory(Intent.CATEGORY_OPENABLE);
                String[] types = params.getAcceptTypes();
                String type = (types != null && types.length > 0 && types[0] != null && types[0].length() > 0) ? types[0] : "*/*";
                intent.setType(type);
                try {
                    startActivityForResult(Intent.createChooser(intent, "Выберите файл"), REQ_FILE);
                } catch (Exception e) {
                    filePathCallback = null;
                    return false;
                }
                return true;
            }
        });

        String page = findHtml();
        if (page != null) {
            web.loadUrl("file:///android_asset/" + page);
        } else {
            StringBuilder sb = new StringBuilder();
            try {
                String[] list = getAssets().list("");
                for (int i = 0; i < list.length; i++) sb.append(list[i]).append("<br>");
            } catch (Exception e) {
                sb.append(e.getMessage());
            }
            web.loadDataWithBaseURL(null,
                "<html><body style='font-size:18px;padding:16px'><h3>В папке assets нет html-файла</h3>"
                + "Положите calculator.html в папку assets (рядом с AndroidManifest.xml) и пересоберите проект.<br><br>"
                + "Сейчас в assets:<br>" + sb + "</body></html>",
                "text/html", "UTF-8", null);
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode == REQ_FILE && filePathCallback != null) {
            Uri[] result = null;
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                result = new Uri[]{data.getData()};
            }
            filePathCallback.onReceiveValue(result);
            filePathCallback = null;
            return;
        }
        if (requestCode == REQ_VOICE) {
            if (resultCode == RESULT_OK && data != null) {
                java.util.ArrayList<String> r = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS);
                if (r != null && r.size() > 0) {
                    web.evaluateJavascript("window.onNativeVoice&&window.onNativeVoice(" + JSONObject.quote(r.get(0)) + ")", null);
                }
            }
            return;
        }
        if (requestCode == REQ_NATIVE) {
            if (resultCode == RESULT_OK && data != null && data.getData() != null) {
                final Uri uri = data.getData();
                final String kind = nativeKind;
                new Thread(new Runnable() {
                    public void run() {
                        try {
                            String url;
                            if (kind.startsWith("snd")) {
                                url = audioToDataUrl(uri);
                            } else {
                                url = imageToDataUrl(uri, kind.startsWith("icon") ? 260 : 1100);
                            }
                            if (url == null) {
                                toast("Не удалось прочитать файл (звук - до 3 МБ)");
                                return;
                            }
                            final String js = "window.onNativeFile&&window.onNativeFile("
                                    + JSONObject.quote(kind) + "," + JSONObject.quote(url) + ")";
                            runOnUiThread(new Runnable() {
                                public void run() { web.evaluateJavascript(js, null); }
                            });
                        } catch (Exception e) {
                            toast("Ошибка: " + e.getMessage());
                        }
                    }
                }).start();
            }
            return;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            public void run() { Toast.makeText(MainActivity.this, msg, Toast.LENGTH_LONG).show(); }
        });
    }

    private String audioToDataUrl(Uri u) throws Exception {
        InputStream in = getContentResolver().openInputStream(u);
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[8192];
        int n, total = 0;
        while ((n = in.read(buf)) > 0) {
            total += n;
            if (total > 3000000) { in.close(); return null; }
            out.write(buf, 0, n);
        }
        in.close();
        String mime = getContentResolver().getType(u);
        if (mime == null) mime = "audio/mpeg";
        return "data:" + mime + ";base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    private String imageToDataUrl(Uri u, int maxSide) throws Exception {
        BitmapFactory.Options o = new BitmapFactory.Options();
        o.inJustDecodeBounds = true;
        InputStream a = getContentResolver().openInputStream(u);
        BitmapFactory.decodeStream(a, null, o);
        a.close();
        int sample = 1;
        while (Math.max(o.outWidth, o.outHeight) / sample > maxSide * 2) sample *= 2;
        o = new BitmapFactory.Options();
        o.inSampleSize = sample;
        InputStream b = getContentResolver().openInputStream(u);
        Bitmap bmp = BitmapFactory.decodeStream(b, null, o);
        b.close();
        if (bmp == null) return null;
        float k = Math.min(1f, (float) maxSide / Math.max(bmp.getWidth(), bmp.getHeight()));
        if (k < 1f) {
            bmp = Bitmap.createScaledBitmap(bmp, Math.round(bmp.getWidth() * k), Math.round(bmp.getHeight() * k), true);
        }
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        bmp.compress(Bitmap.CompressFormat.JPEG, 82, out);
        return "data:image/jpeg;base64," + Base64.encodeToString(out.toByteArray(), Base64.NO_WRAP);
    }

    // Ищет index.html, а если его нет, то любой .html в assets
    private String findHtml() {
        try {
            String[] list = getAssets().list("");
            for (int i = 0; i < list.length; i++) {
                if (list[i].equals("index.html")) return list[i];
            }
            for (int i = 0; i < list.length; i++) {
                if (list[i].toLowerCase().endsWith(".html")) return list[i];
            }
        } catch (Exception e) {
        }
        return null;
    }

    @Override
    public void onBackPressed() {
        if (web.canGoBack()) web.goBack(); else super.onBackPressed();
    }
}
